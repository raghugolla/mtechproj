
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>

int matrix[16][16],rkey[256],bits[256];
int length,r_num,e_num,s_num,s_num1=0;
int Sum(char key[],int);
int rand_num(int sum);
int encryption_num(int sum);
void read_file();
void create_matrix();
void randomize_matrix();
void encrypt();
void decrypt();
void rightshift();
void leftshift();
void XOR();
void substitution_num(char text_key[],int);
void encryp();
 
 FILE *infile,*ef,*df;
int main()
{
    time_t t1,t2;
    char text_key[17];
    unsigned int sum;
  ef=fopen("encrypt.txt","a");
  if(ef==NULL)
  printf("unable to open file");
      infile=fopen("dump.txt","r");
    
    printf("Enter the 16 character key\n");
    scanf("%s",text_key);
    
    t1=time(NULL);
    length=strlen(text_key);
    sum=Sum(text_key,length);
    r_num=rand_num(sum);
    e_num=encryption_num(sum);
    substitution_num(text_key,sum);
    create_matrix();
    randomize_matrix();
    read_file();
    encryp();
    t2=time(NULL);
    printf("%f",(float)t2-(float)t1);
    
    return 0;
}    
   
int Sum(char key[],int len)
{
    int i,base=18-len;                              //calculate the base value
    double sum=0;
    for(i=1;i<=len;i++)
    {
        sum+=key[i-1]*pow(base,i);
    }    
    return (int)sum;
}   

int rand_num(int sum)                                  //to generate the randomization number
{
    int i;
    int num1,temp=sum,count=0,rem,ran_num=0;
    while(temp!=0)
    {
        temp=temp/10;
        count++;
        
    }   
    temp=sum;
     for(i=count;i>=1;i--)
     {
         rem=temp%10;
         temp=temp/10;
         ran_num+=rem*i;
     }     
     ran_num=sum%ran_num;
     if(ran_num==0)
     ran_num=sum;
     else if(ran_num>32)
     ran_num=ran_num%32;
     return ran_num;
} 

int encryption_num(int sum)                                //to generate the encryption number
{
    int num1,temp=sum,count=0,rem,enc_num=0,i;
    while(temp!=0)
    {
        temp=temp/10;
        count++;
        
    }   
    temp=sum;
     for(i=1;i<=count;i++)
     {
         rem=temp%10;
         temp=temp/10;
         enc_num+=rem*i;
     }     
     
       enc_num=sum%enc_num;
     if(enc_num==0)
     enc_num=sum;
     else if(enc_num>32)
     enc_num=enc_num%32;
     return enc_num;
}        
void substitution_num(char text_key[],int sum)
{
    int i;
    for(i=0;i<strlen(text_key);i++)
    {
        s_num1+=text_key[i]*(i+1);
    }   
    int temp=sum,count=0,rem;
    while(temp!=0)
    {
        temp=temp/10;
        count++;
        
    }   
    temp=sum;
     for(i=count;i>=1;i--)
     {
         rem=temp%10;
         temp=temp/10;
         s_num+=rem;
     }     
     s_num=s_num1%s_num;
    /*printf("%d",s_num);
     
     exit(0);*/    
}    
void read_file()                              //reading the file
{
    char str[33],c='@',str1[33];
    c=c<<1;
    int index=0,r=0,in=0,i,j,k,count=0,ch;
    create_matrix();
    randomize_matrix();
   
  A:
      index=0;
    for(i=0;i<32;i++)
    {
       ch=fgetc(infile);
        if(ch==EOF)
       {
         break;       
    	}        
       str[i]=ch;      
    }        
   if(i<31)
   {
       while(i!=32)
       {
        str[i++]=6; //NULL has replaced with ""
       }    
       for(i=0;i<256;i++)
       {
           bits[i]=0;
       }    
   }    
    for(j=0;j<32;j++)
   {
		for(k=0;k<8;k++)
		{ 
		  str1[j]=str[j]&c;                     //converting bytes to bits 
		  if(str1[j]!='\0')  //NULL has replaced with ""
		  bits[index++]=1;
		  else
		  bits[index++]=0;
		  str[j]=str[j]<<1;
		}    
   }
    encrypt();
    if(ch==EOF)
    {
        fclose(infile);
        fclose(ef);
        return;
  }    
    else
    goto A;
}    

void create_matrix()
{
    int k=0,i,j;
    for(i=1;i<=16;i++)
    {
        for(j=1;j<=16;j++)
        {
          matrix[i-1][j-1]=k++;
        }    
    }
}    

void randomize_matrix()
{

 int key[256];
 int index=0,i,j;
    for(i=0;i<16;i++)
    {
        for(j=0;j<16;j++)
        {
          key[index]=matrix[i][j];
          index++;
        }    
    }
     for(i=0;i<256;i++)
    {
        rkey[i]=key[(((i+r_num)%256)+e_num)%256];
    }    
}    

void encrypt()
{
    int temp,num;
    int buf=0,i;
    char c;
 for(i=0;i<256;i++)                       //interchanging the bits
  {
      num=rkey[i];
      temp=bits[i];                          
      bits[i]=bits[num];
      bits[num]=temp;
  } 
  
     for(i=1;i<=e_num;i++)
     {
         
         rightshift();
         XOR();
     }                 
     
          for(i=0;i<256;i=i+8)
          {
              
              buf=bits[i]*128+bits[i+1]*64+bits[i+2]*32+bits[i+3]*16+bits[i+4]*8+bits[i+5]*4+bits[i+6]*2+bits[i+7]*1;
              c=buf;
              fputc(c,ef);
              buf=0;
          }    
                              
}   

void rightshift()
{
    int i,temp;
    temp=bits[255];
    for(i=0;i<255;i++)
    {
      bits[255-i]=bits[254-i];  
    }    
    bits[0]=temp;
}    
void XOR()
{
    int i;
    for(i=0;i<256;i=i+2)
    {
        bits[i+1]=bits[i]^bits[i+1];
    }    
}   

void encryp()
{
    char c1;
    int k;
    
    infile=fopen("encrypt.txt","r");
      ef=fopen("encrypt1.txt","a");
      while(!feof(infile))
      {
          c1=fgetc(infile);
          k=(int)c1;
          k=(k+s_num)%256;
          c1=(char)k;
          fputc(c1,ef);
      }    
    fclose(ef);
    fclose(infile);
}    
