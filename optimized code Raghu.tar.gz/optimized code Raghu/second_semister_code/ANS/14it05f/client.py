import socket   #for sockets
import sys  #for exit
import time;
from datetime import datetime
 
#create an INET, STREAMing socket
try:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)##create an AF_INET, STREAM socket (TCP)
except socket.error:
    print 'Failed to create socket'
    sys.exit()
     
print 'Socket Created'
 
host = "";
port = 9001
 
try:
    remote_ip = socket.gethostbyname( host )
 
except socket.gaierror:
    #could not resolve
    print 'Hostname could not be resolved. Exiting'
    sys.exit()
 
#Connect to remote server put the data in one fun
s.connect((host , port)) 
message="hello server\n"
t1 = datetime.now()
print t1
try :
    
    #s.send(" select sname from sailors,boats where sid=bid ;")
    #s.send("select * from sailors where sname=1 OR sid=56 OR 1=0 OR 1=1;") #blind
    #s.send("select * from sailors where sname=1 OR 1=1;")#taut
    #s.send("select * from sailors where sid=56 OR 1=1;sudo mysql.server stop;")#stored
    s.send("select * from sailors where sid=1;drop table boats;")
    #s.send("select * from sailors where sname=1 OR sid=56 OR 1=0 OR 1=1;")
    print 'Message send successfully'
    #---------------------------- in the above line you can change the name of the relation which ever you want----------------------
    #s.send("hi server")
    #var2 =  systime()
    #var2 - var1
    data = s.recv(4096)
    print data
    t2 = datetime.now()
    print t2 
    t=t2-t1
    print "responce time:"
    print t
except socket.error:
    #Send failed
    print 'Send failed'
    sys.exit()
 

 

