#!/usr/bin/python

import os
import commands
import time

#var = os.system("pidof gedit")

var = commands.getstatusoutput("pidof gedit")

var=var[1]

#print var

commands.getstatusoutput("sudo kill -s SIGSTOP "+str(var))

time.sleep(10)

commands.getstatusoutput("sudo kill -s SIGCONT "+str(var))


#print var


