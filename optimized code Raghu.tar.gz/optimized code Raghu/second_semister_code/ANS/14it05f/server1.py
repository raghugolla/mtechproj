import socket
import MySQLdb
import sys
from thread import *
 
HOST = ''   # Symbolic name meaning all available interfaces
PORT = 9001 # Arbitrary non-privileged port
 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print 'Socket created'
 
#Bind socket to local host and port
try:
    s.bind((HOST, PORT))
except socket.error , msg:
    print 'Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    sys.exit()
     
print 'Socket bind complete'
 
#Start listening on socket
s.listen(10)
print 'Socket now listening'
db = MySQLdb.connect("localhost","root","root","raghu" )
cursor = db.cursor()
#cursor.execute(data)
while 1:
    #wait to accept a connection - blocking call
    conn, addr = s.accept()
    print 'Connected with ' + addr[0] + ':' + str(addr[1])
    
    #while True:
    data = conn.recv(1024)
    print data
    #conn.send(" got it")
    cursor.execute(data)
    string = ""
    for row in cursor:
    	#print row
    	stri = ""
    	for me in row:
    		stri = stri+str(me)+" "
    	#print stri
    	#row = "".join(str(d) for d in row)
    	string = string + stri+"\n" 
    conn.send(string)
    #print data
    
    #reply = 'OK...' + data
    #conn.sendall(reply)
     
    #came out of loop
    #conn.close()
     
    import socket
import MySQLdb
import sys
from thread import *
 
HOST = ''   # Symbolic name meaning all available interfaces
PORT = 9000 # Arbitrary non-privileged port
 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print 'Socket created'
 
#Bind socket to local host and port
try:
    s.bind((HOST, PORT))
except socket.error , msg:
    print 'Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    sys.exit()
     
print 'Socket bind complete'
 
#Start listening on socket
s.listen(10)
print 'Socket now listening'
db = MySQLdb.connect("localhost","root","root","raghu" )
cursor = db.cursor()
#cursor.execute(data)
while 1:
    #wait to accept a connection - blocking call
    conn, addr = s.accept()
    print 'Connected with ' + addr[0] + ':' + str(addr[1])
    
    #while True:
    data = conn.recv(1024)
    print data
    #conn.send(" got it")
    cursor.execute(data)
    string = ""
    for row in cursor:
    	#print row
    	stri = ""
    	for me in row:
    		stri = stri+str(me)+" "
    	#print stri
    	#row = "".join(str(d) for d in row)
    	string = string + stri+"\n" 
    conn.send(string)
    #print data
    
    #reply = 'OK...' + data
    #conn.sendall(reply)
     
    #came out of loop
    #conn.close()
     
      
