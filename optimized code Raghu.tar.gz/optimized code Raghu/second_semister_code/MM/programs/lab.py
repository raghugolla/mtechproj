from Tkinter import *
import ttk


def huffman():
    c.delete(all)
    inp = ttk.Entry(leftf,width=8)
    inp.grid(row=0,column=4,sticky=(W+E))
    inp.bind('<Return>', (lambda event: encode())) 
    inp.focus_set()
    s1=ttk.Button(leftf,text="encode",command=encode)
    s1.grid(row=2,column=4,padx=10,pady=10,sticky=(E+W))

def encode():
    txt=inp.get()
    symb2freq = defaultdict(int)
    for ch in txt:
        symb2freq[ch] += 1
    heap = [[wt, [sym, ""]] for sym, wt in symb2freq.items()]
    heapify(heap)
    while len(heap) > 1:
        lo = heappop(heap)
        hi = heappop(heap)
        for pair in lo[1:]:
            pair[1] = '0' + pair[1]
        for pair in hi[1:]:
            pair[1] = '1' + pair[1]
        heappush(heap, [lo[0] + hi[0]] + lo[1:] + hi[1:])
    huff=sorted(heappop(heap)[1:], key=lambda p: (len(p[-1]), p))
    s=''
    for p in huff:
        s=s+p[1]

    return s 

    








root = Tk()
leftf = ttk.Frame(root,padding=50)
leftf.pack(side=TOP)
c = Canvas(leftf,width=600,height=500,background="grey")
c.pack()
s=ttk.Button(leftf,text="huffman",command=huffman)
s.grid(row=2,column=4,padx=10,pady=10,sticky=(E+W))
sl=ttk.Button(leftf,text="rle",command=rle)
sl.grid(row=2,column=8,padx=10,pady=10,sticky=(E+W))
slzw=ttk.Button(leftf,text="lzw",command=lzw)
slzw.grid(row=4,column=4,padx=10,pady=10,sticky=(E+W))



