str1=raw_input("enter the string:")
print "the string is:",str1
print "a:"
print "the encoding is:"
c=1
temp=""
for e,i in enumerate(str1):
    if e>0:
        if i==str1[e-1]:
            c+=1
        else:
            temp+=str1[e-1]+str(c)
            c=1
temp+=str1[e]+str(c)
print temp
print "b:"
pat=int(raw_input("enter the number of the patterns you want in descending order:"))
length = len(str1)
alist,blist = [],[]
maxx=0
for i in xrange(length):
    for j in xrange(i,length):
        alist.append(str1[i:j + 1])
        if len(str1[i:j+1])>maxx:
               maxx=len(str1[i:j+1])
#print alist
while(maxx>0):
    for each in alist:
        if len(each)==maxx:
            blist.append(each)
    maxx-=1
print blist[0:pat]
print "c:"
str2=int(raw_input("enter the length of the patterns:"))
print str(str2)
dict={}
arr=[]
for e,i in enumerate(str1):
    temp1=str1[e:e+str2]
    if len(temp1)==str2:
        if temp1 not in dict:
            c1=0
            for e1,i1 in enumerate(str1):
                temp11=str1[e1:e1+str2]
                if temp1==temp11:
                    c1+=1
            dict[temp1]=c1
            if c1 not in arr:
                arr.append(c1)
#print dict
arr.sort()
arr.reverse()
#print arr
t=""
for each in arr:
    for key in dict:
        if dict[key]==each:
            t+="("+key+","+str(each)+")"+","
t=t[0:len(t)-1]
print t

            
        
    
