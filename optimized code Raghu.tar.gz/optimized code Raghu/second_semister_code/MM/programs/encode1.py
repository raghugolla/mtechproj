from collections import Counter
#def union():
#    print dict(list(a.items())+list(b.items()))


a='aabbccddabaasbdbajskzksjazaikqqzkaksaasssdaabccdsaslsll'
z=[a[i:i + 2] for i in range(0, len(a), 2)]
print z
print "-------"
z1=[a[i:i + 2] for i in range(1, len(a), 2)]
print z1
print "freq count"
a=dict((letter,z.count(letter)) for letter in set(z))
print a
print "---------------------------------------------------"
b=dict((letter,z1.count(letter)) for letter in set(z1))
print b

A=Counter(a)
B=Counter(b)
print A+B
