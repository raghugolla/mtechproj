str1=raw_input("enter the string:")
p=""
c=""
pc=""
dict1={}
count=0
for each in str1:
    if each not in dict1:
        count+=1
        dict1[each]=count
print dict1
#dict1={"a":1,"b":2,"w":3}
encode=""
for e in str1:
    c=e
    pc=p+c
    if pc not in dict1:
        count+=1
        dict1[pc]=count
        print dict1[p],
        encode+=str(dict1[p])
        p=c
    else:
        p=pc
    c=""
    pc=""
encode+=str(dict1[p])
print dict1[p]
print dict1
print encode
dict2={}
count=0
for each in str1:
    if each not in dict2:
        count+=1
        dict2[each]=count
print dict2
spw=""
scw=""
p=""
c=""
pc=""
decode=""
for each in encode:
    cw=int(each)
    for every in dict2:
        if dict2[every]==cw:
            scw=every
            decode+=scw
            p=spw
            c=scw[0]
            pc=p+c
            if pc not in dict2:
                count+=1
                dict2[pc]=count
            pw=cw
            spw=scw
            break
print dict2
print decode   
    
