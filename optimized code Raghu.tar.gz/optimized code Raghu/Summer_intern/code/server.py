
import socket
import os
import re
#def func():
def execute():
	os.system("gcc "+"add.c")
	var = os.system("./a.out")
	#print "sum is : "+str(var)

host = "10.100.54.56"
port = 5005

s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
print "socket created"
s.bind((host,port))
print "binded"
s.listen(10)
print "listening"
print "Server started...."
while True:
	print "inside the while loop"
	conn,addr = s.accept()
	print "connection accepted"
	data =  conn.recv(1024)
	print data
	print "recived data is ......."+str(data)
	print str(data)
	
	#data = int(data)
	
	if data == "514":
		print "inside the 514"
		os.system("free -m > memory")
		fp = open("memory","r")
		count=0
		for line in fp:
			count+=1
			if count==2:
				line = re.sub(' +',' ',line)
				line=line.split(" ")
				line = line[2]
				conn.send(line)
		
		#-----> code for performance 
		#return performance
	elif( data == "515" ):
		print "inside the 515"
		fp = open("add.c","w")
		flag=1
		while True:
			if flag==1:
				conn.send("ok")
				flag=0
			data =  conn.recv(1024)
			print data
			if(str(data)=="L"):
				break
			fp.write(str(data))
			
		fp.close()
		execute()
		
		#conn.send(value
	conn.close()

	#data = raw_input(" -> : ")
	#print "from connected user.... "+str(addr)
	#data = str(data).upper()
	#conn.send(data)

s.close()
