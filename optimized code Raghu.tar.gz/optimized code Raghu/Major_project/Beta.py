from itertools import izip
import random
import csv
#iam assuming node numbers 3,9,5 are mallicious
n=int(raw_input("please enter the no.of nodes"))
m=int(raw_input("please enter how many iterations you want:"))
lower = int(raw_input("enter lowest temperature value: "))
upper = int(raw_input("enter maximum temperature value: "))
#k=0;
s1=[]
aa=[]
bb=[]
cv=[]
id1=[]


"""file=open('data.txt','w')
file.write(str("name") + " " + str("roll") + "\n")"""

for i in range(n):
	aa.append(0)
for k in range(n):
	bb.append(0)
for i in range(n):
	s1.append(0)
for i in range(n):
	cv.append(0)
for i in range(n):
	id1.append(i)
def display():
		#s1 = []
        for i in range(n):
        	if (i==300000)or(i==50000)or(i==90000):
        		num=random.randint(75,95)
        		s1[i]=num
        	else:
        		num = random.randint(lower, upper)
            	s1[i]=num
        return s1

#print display()

def fun():
		k=sum(s1)
		k=float(k/n)
		return k
#a=fun()
#print "average of all nodes is:",a
def fun1():
		for i in range(n):
			if (s1[i]-5<a)and(s1[i]+5>a):
				#print"node is malcious",i
				aa[i]=aa[i]+1
			else:
				#print "in the iteraton:",i
				print"\nnode",i,"is malcious"
				bb[i]=bb[i]+1
#fun1()
s=open('consistency.txt', 'w')
#s.write("aa|bb| cv\n")
s.close()
p=open('bb.txt','w')
#p.write("bb value")
p.close()
q=open('aa.txt','w')
#q.write("aa value\n")
q.close()
for i in range(m):
	#print "\n\n********************************************\n\n"
	print "\n\nIn the iteraton:",i,
	display()
	a=fun()
	#print "average of all nodes is:",a
	fun1()
	#file=open('data[i].txt','w')
	#file.write(str("name") + " " + str("roll") + "\n")
	#file.close()
	for l in range(n):
		p=float(aa[l]+1)
		q=float(aa[l]+bb[l]+2)
		if q==0:
			cv[l]=0
		else:
			cv[l]=float(p/q)
	#print aa
	if (i%8==0):
		#print"\n\n#########################**************#######################\n\n"
		#print "cv value:------------->",cv
		with open('consistency.txt', 'a') as f:
			writer = csv.writer(f)
			#writer.writerow(["\n"])
			writer.writerow(["\nnext iteration\n"])
			writer.writerow(["ID aa bb CTV"])
			writer.writerows(izip(id1,aa,bb,cv))
		#print"\n\n#########################**************#######################\n\n"
		print " "
		
	with open('alpha.txt', 'a') as f:
		writer = csv.writer(f)
		writer.writerow(["ID cons"])
		writer.writerows(izip(id1,aa))
		
	with open('beta.txt', 'a') as f:
		writer = csv.writer(f)
		writer.writerow(["ID incon"])
		writer.writerows(izip(id1,bb))

"""i=0
j=0
with open("bb.txt",'r') as f3:
	for line in f3:
		if i%(n+1) == 0:
			print line[:5]+"\t\t"+"ID aa"
		else:
			print line[:3]+"\t\t"+str(bb[j])
			#line = line+"\t"+"peter"
			j=j+1
			#print line
		i=i+1"""
	
