from itertools import izip
import random
import csv
import math
#iam assuming node numbers 3,9,5 are malicious
#we are fixing the distance of node1 in (25,25), closed loop nodes in the rage of(50,50) and outer loop nodes are in the range of (75,75)
n=int(raw_input("please enter the no.of nodes"))
m=int(raw_input("please enter how many iterations you want:"))
lower = int(raw_input("enter lowest temperature value: "))
upper = int(raw_input("enter maximum temperature value: "))
#k=0;
s1=[]
cc=[]
ic=[]
cv=[]
id1=[]
dist=[]
da=[]
t=[]


"""file=open('data.txt','w')
file.write(str("name") + " " + str("roll") + "\n")"""

for i in range(n):
	cc.append(0)
for k in range(n):
	ic.append(0)
for i in range(n):
	s1.append(0)
for i in range(n):
	cv.append(0)
for i in range(n):
	id1.append(i)
	
for i in range(n):
	dist.append(0)

for i in range(n):
	da.append(0)
for i in range(n):
	t.append(0)
	
def display():
		#s1 = []
        for i in range(n):
        	num = random.randint(lower, upper)
        	s1[i]=num
        	da[i]=num
        return s1

#print display()

def distance():
	p1=35.551
	p2=70.01
	for i in range(n):
		if (i<=5):
			dist[i]=float(1/p1)
			#print dist[i]
		else:
			dist[i]=float(1/p2)
	return dist

distance()



def fun():
		k=sum(s1)
		k=float(k/n)
		return k
		for i in range(n):
			da[i]=da[i]-k
a=fun()
print "average of all nodes is:",a


def davg():
	for i in range(n):
		k=sum(s1)
		k=float(k/n)
		da[i]=s1[i]
	return da
	
lpq=davg()

print "hello",a


def fun1():
		for i in range(n):
			if (s1[i]-5<a)and(s1[i]+5>a):
				#print"node is malicious",i
				cc[i]=cc[i]+1
			else:
				print"node is malicious",i
				ic[i]=ic[i]+1
#fun1()
s=open('consistency.txt', 'w')
#s.write("cc|ic| cv\n")
s.close()
p=open('ic.txt','w')
#p.write("ic value")
p.close()
q=open('cc.txt','w')
#q.write("cc value\n")
q.close()
for i in range(m):
	print "********************************************"
	print "\n\nIn the iteraton:",i,
	print display()
	a=fun()
	print "average of all nodes is:",a
	fun1()
	#file=open('data[i].txt','w')
	#file.write(str("name") + " " + str("roll") + "\n")
	#file.close()
	for l in range(n):
		p=float(cc[l]-ic[l])
		q=float(cc[l]+ic[l])
		if q==0:
			cv[l]=0
		else:
			cv[l]=float(p/q)
	print cc
	#================print "distance value",dist
	for i in range (n):
		da[i]=da[i]-a
	print "this the difference of average",da
	#print "this the list of temp",s1
	
	def trust():
		for i in range(n):
			t[i]=((0.3*dist[i])+(0.2*da[i])+(0.5*cv[i]))
	trust()
	print "trust value",t	
	
		
	
	if (i%8==0):
		print"#########################**************#######################"
		print "cv value:------------->",cv
		with open('consistency.txt', 'a') as f:
			writer = csv.writer(f)
			#writer.writerow(["\n"])
			writer.writerow(["\nnext iteration\n"])
			writer.writerow(["ID CC IC CV CTV"])
			writer.writerows(izip(id1,cc,ic,cv))
		print"#########################**************#######################"
		print " "
		
	with open('cc.txt', 'a') as f:
		writer = csv.writer(f)
		writer.writerow(["ID CC"])
		writer.writerows(izip(id1,cc))
		
	with open('ic.txt', 'a') as f:
		writer = csv.writer(f)
		writer.writerow(["ID IC"])
		writer.writerows(izip(id1,ic))

"""i=0
j=0
with open("ic.txt",'r') as f3:
	for line in f3:
		if i%(n+1) == 0:
			print line[:5]+"\t\t"+"ID CC"
		else:
			print line[:3]+"\t\t"+str(ic[j])
			#line = line+"\t"+"peter"
			j=j+1
			#print line
		i=i+1"""
	
