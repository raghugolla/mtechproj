from itertools import izip
import random
import csv
import numpy as np
import math 

s1=[]
s2=[]
s3=[]
s4=[]
s5=[]
s99=[]
s88=[]
s77=[]
n=int(raw_input("please enter the no.of time intervels"))
lower = int(raw_input("enter lowest temperature value: "))
upper = int(raw_input("enter maximum temperature value: "))
x=int(raw_input("enter the no.of iterations:"))
for i in range(n):
	s1.append(0)

for i in range(n):
	s2.append(0)

for i in range(n):
	s3.append(0)
	
for i in range(n):
	s4.append(0)

for i in range(n):
	s5.append(0)

for i in range(n):
	s99.append(0)
for i in range(n):
	s88.append(0)
	
for i in range(n):
	s77.append(0)	
		
for i in range(x):
	def display1():
			for k in range(n):
				num=random.randint(lower, upper)
				s1[k]=num
			return s1
	def display2():
			for k in range(n):
				num = random.randint(lower, upper)
				s2[k]=num
			return s2
	def display3():
			for k in range(n):
				num = random.randint(lower, upper)
				s3[k]=num
			return s3
	def display4():
			for k in range(n):
				num = random.randint(lower, upper)
				s4[k]=num
			return s4
	def display5():
			for k in range(n):
				num = random.randint(lower, upper)
				s5[k]=num
			return s5
	display1()
	display2()
	display3()
	display4()
	display5()
	def display99():
			for k in range(n):
				s99[k]=s1[k]-s2[k]
			return s99
	def display88():
			for k in range(n):
				s88[k]=s1[k]-s3[k]
			return s88
	def display77():
			for k in range(n):
				s77[k]=s1[k]-s4[k]
			return s77
	display99()
	display88()
	display77()
	m=np.mean(s99)
	v=np.var(s99)
	st=np.std(s99)
	m2=np.mean(s88)
	v2=np.var(s88)
	st2=np.std(s88)
	m3=np.mean(s77)
	v3=np.var(s77)
	st3=np.std(s77)
	#print "*************node1 and node2*************"
	#print"mean:",m
	#print"vari:",v
	#print "std:",st
	#print "*************node1 and node3*************"
	#print "mean value of the node1 and node2 is:",m2
	#print"variance is:",v2
	#print "standard deviation is:",st2
	#print "*************node1 and node34*************"
	#print "mean value of the node1 and node2 is:",m3
	#print"variance is:",v2
	#print "standard deviation is:",st3
	#print"********************************************"
	e=.5
	x1=float((e-m)/st)
	y1=float((-e-m)/st)
	x2=float((e-m2)/st2)
	y2=float((-e-m2)/st2)
	x3=float((e-m3)/st3)
	y3=float((-e-m3)/st3)
	#print"the values is",x1,y1
	l=(-(x1*x1)/2)
	m=(-(y1*y1)/2)
	l2=(-(x2*x2)/2)
	m2=(-(y2*y2)/2)
	l3=(-(x3*x3)/2)
	m3=(-(y3*y3)/2)
	p=np.exp(l)
	q=np.exp(m)
	p2=np.exp(l2)
	q2=np.exp(m2)
	p3=np.exp(l3)
	q3=np.exp(m3)
	k1=((float((0.5)+(0.000165893)*p*(x1+((math.pow(x1,3)/3))+((math.pow(x1,5))/15)+((math.pow(x1,7))/105))))-(float((0.5)+(0.000165893)*q*(y1+((math.pow(y1,3)/3))+((math.pow(y1,5))/15)))))*100
	k2=((float((0.5)+(0.000165893)*p*(x2+((math.pow(x2,3)/3))+((math.pow(x2,5))/15))))-(float((0.5)+(0.000165893)*q*(y2+((math.pow(y2,3)/3))+((math.pow(y2,5))/15)))))*100
	k3=((float((0.5)+(0.000165893)*p*(x3+((math.pow(x3,3)/3))+((math.pow(x3,5))/15))))-(float((0.5)+(0.000165893)*q*(y3+((math.pow(y3,3)/3))+((math.pow(y3,5))/15)))))*100
	if i==0:
		print "Trustness                  iteration             node2              Node3            Node4"
	print"  iteration                  ",i,"    ",k1,"  ",k2,"  ",k3


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

