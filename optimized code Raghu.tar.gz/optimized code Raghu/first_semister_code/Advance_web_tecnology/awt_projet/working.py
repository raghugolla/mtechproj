
import urllib2  #  url lib
import re
inpturl = raw_input("enter  the product name:  ")
inpturl = "http://www.flipkart.com/"+inpturl+"s/pr?q="+inpturl+"&as=on&as-show=on&otracker=start&sid=6bo%2Cb5g&as-pos=1_1_ic"
if len(inpturl)<4:

    response = urllib2.urlopen("http://www.flipkart.com/mobiles/pr?q=mobile&as=on&as-show=on&otracker=start&sid=tyy%2C4io&as-pos=1_1_ic").read()
else:
   response = urllib2.urlopen(inpturl).read()


response = urllib2.urlopen(inpturl).read()
try:
	fp = open("flipkartp.txt","w")
	fp.write(response)
except:
	print " something went wrong while writing in file"
fp.close()


"""by using this we can extract the html page """


import re
fp = open("pricep","w");
shakes = open("flipkartp.txt", "r")

for line in shakes:
    if re.match("                                <span class=\"fk-", line):
	#if re.match("          <span class="a-size-small a-color-price"><span class="currencyINR">&nbsp;&nbsp;</span>", line):
        fp.write(line.strip()+"\n");
		#print line
    else:
        print""

fp.close()
"""by using above code we can extract the requried field"""

"""

fh = open("xyz.txt", "r")
lines = fh.readlines()
fh.close()
# Weed out blank lines with filter
lines = filter(lambda x: not x.isspace(), lines)
# Write "transfer-out/"+file+".txt", "w"
fh = open("xyz.txt", "w")
#fh.write("".join(lines))
# should also work instead of joining the list:
fh.writelines(lines)
fh.close()  """

fp = open("pricep","r")
fp1 = open("pricp.py","w")
fp1.write("array = [")
for line in fp:
	var = re.search(r'class(.*?)Rs. (.*)\</span', line)
	fp1.write(var.group(2).replace(",","")+",")
	#print var.group(2)
fp1.write("]")
diff = [[0 for x in range(1)] for y in range(10)]
one = [0]*10

#print diff
fp.close()
fp1.close()

from pricp import array

#print len(array)

tot = []
fp = open("pricp.py","r")
for price in array:
	'''print price,type(price)
	inte = int(price)
	print inte,type(price) '''


	if price >= 10000 and price <= 20000:
		one[0] = one[0]+1
		if price not in diff[0]:
			#print "price added"
			diff[0].append(price)
	if price >= 20000 and price <= 30000:
		one[2] = one[2]+1
		if price not in diff[2]:
			#print "price added"
			diff[2].append(price)
	if price >= 30000 and price <= 40000:
		one[3] = one[3]+1
		if price not in diff[3]:
			#print "price added"
			diff[3].append(price)
	if price >= 40000 and price <= 50000:
		one[4] = one[4]+1
		if price not in diff[4]:
			#print "price added"
			diff[4].append(price)
   	if price >= 50000 and price <= 60000:
   		one[5] = one[5]+1
   		if price not in diff[5]:
   			#print "price added"
   			diff[5].append(price)
	if price >= 60000 and price <= 70000:
		one[6] = one[6]+1
		if price not in diff[6]:
			#print "price added"
			diff[6].append(price)
	if price >= 70000 and price <= 80000:
		one[7] = one[7]+1
		if price not in diff[7]:
			#print "price added"
			diff[7].append(price)
	if price >= 80000 and price <= 90000:
		one[8] = one[8]+1
		if price not in diff[8]:
			#print "price added"
			diff[8].append(price)
	if price >= 90000 and price <= 100000:
		one[9] = one[9]+1
		if price not in diff[9]:
			#print "price added"
			diff[9].append(price)

print "   price range   |different price items| number of products"
for i in range(0,10):
    print " |",str(i)+"0000","-",str(i+1)+"0000   ","                ",(len(diff[i])-1),"      |           ",one[i]," | "

print "\n\n\n\n"
"""byusing this we can remove the white spaces in file"""






"Final Invoice for"+booking.goods_category+"Shifting (Booking ID: "+booking.booking_id+")"

"Final Invoice for %s Shifting (Booking ID: %s" % (booking.goods_category, booking.booking_id)




