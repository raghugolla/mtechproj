# To sort the elements using 2 stacks
# When an element is obtained from console, it is inserted into its "right" position in the list

# s1 and s2 are the two stacks used
# After any operation, s1 has the sorted list and s2 is used for sorting

s1 = []
s2 = []
max_size = 0
item=0
i=0
ch=0

def insert() :
    global s1,s2,max_size,item
    if len(s1) == max_size :
        print "List is full and sorted, you have to exit"
        return
    item=int(raw_input("\nEnter the item to be inserted : "))
    i=len(s1)-1
    while i >= 0 and item >= s1[i] :
        s2.append(s1[i])
        i=i-1
        s1=s1[0:len(s1)-1]
    s1.append(item)
    while len(s2) != 0 :
        s1.append(s2[len(s2)-1])
        s2=s2[0:len(s2)-1]
    i=len(s1)-1
    print "The sorted list is : ",
    while i >= 0 :
        print s1[i],
        i=i-1
    print ""

# End of insert function

# Code Execution starts here :

max_size=int(raw_input("\nEnter the maximum size of list : "))

while ch != 2 :
    ch=int(raw_input("\nOptions : 1. Insert  2. Exit  : "))
    if ch == 1 :
        insert()
    elif ch != 2 :
        print "Wrong Choice"
    else :
        print ""

var_n=raw_input()


            
