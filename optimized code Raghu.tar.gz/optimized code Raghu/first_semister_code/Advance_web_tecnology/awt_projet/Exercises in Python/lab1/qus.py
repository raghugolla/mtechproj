# To implement queue using stacks
# enqueue() and dequeue() are the two functions written for this

# s1 and s2 are the two stacks used here(s1's top is the front!! Confusing!!)
# after any operation, s1 has the queue data and s2 will be empty

s1 = []
s2 = []
max_size = 0

def display() :
    global s1
    if len(s1) == 0 :
        print "Queue is empty! Insert some elements"
    else :
        print "The elements in the queue are : ",
        i=len(s1)-1
        while i >= 0 :
            print s1[i],
            i=i-1
        print ""

# End of display()

def enqueue() :
    global s1,s2,max_size
    if len(s1) == max_size :
        print "\nThe queue is full! Delete some elements"
    else :
        item=int(raw_input("\nEnter the element to be queued : "))
        i=len(s1)-1
        while i >= 0 :
            s2.append(s1[i])
            i=i-1
        s1=[]
        s1.append(item)
        i=len(s2)-1
        while i >=0 :
            s1.append(s2[i])
            i=i-1
        s2=[]
        print "Element inserted successfully"
        display()

# end of enqueue()

def dequeue() :
    global s1,s2
    if len(s1) == 0 :
        print "Queue is empty! Queue some elements"
    else :
        item=s1[len(s1)-1]
        s1=s1[0:len(s1)-1]
        print "Element deleted successfully"
        display()
        
# End of dequeue()

# Execution starts here!!

print "\nImplementing queues using stacks...."
max_size = int(raw_input("\nEnter the maximum size of the queue : "))

ch=0;

while ch != 3 :
    ch=int(raw_input("\nOptions : 1. Insert  2. Delete  3. Exit  : "))
    
    if ch == 1 :
        enqueue()
    elif ch == 2 :
        dequeue()
    elif ch != 3 :
        print "Wrong option"
    
var_n=raw_input()




