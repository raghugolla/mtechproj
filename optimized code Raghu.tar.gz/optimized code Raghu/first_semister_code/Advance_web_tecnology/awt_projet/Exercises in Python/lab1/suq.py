# To implement a stack using queues 
# push() and pop() functions are written for the purpose

# q1 and q2 are two queues
# After any operation, q1 contains the stack data and q2 is empty

max_size=0
q1=[]
q2=[]

def display() :
    global q1
    if len(q1) == 0 :
        print "Stack is empty! Push some items."
    else :
        print "The items in the stack is : ",
        print q1

def push() :
    global max_size, q1, q2
    if len(q1) == max_size :
        print "\nStack is full! Pop some items."
    else :
        item=int(raw_input("\nEnter the item to be pushed : "))
        q2.append(item)
        for i in range(0,len(q1)) :
            q2.append(q1[i])
        q1=q2
        q2=[]
        print "Item pushed successfully"
        display()
        
# End of push()


def pop() :
    global q1
    if len(q1) == 0 :
        print "Stack is empty! Push some items."
    else :
        q1=q1[1:]
        print "Item popped successfully"
        display()
        
# End of pop()
            

# program execution starts here

print "\nImplementing stacks using queues...."
max_size = int(raw_input("\nEnter the maximum size of the stack : "))

ch=0;

while ch != 3 :
    ch=int(raw_input("\nOptions : 1. Push  2. Pop  3. Exit  : "))
    
    if ch == 1 :
        push()
    elif ch == 2 :
        pop()
    elif ch != 3 :
        print "Wrong option"
    
var_n=raw_input()
