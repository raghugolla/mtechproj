# This program reverses a given string
# Get the string in 'strn' and the reverse is stored in 'rev'

strn = raw_input("Enter the string to be reversed : ")
length=len(strn)

# print "Length of input string is :%s" % (length)

# Check if input is not empty
ch=1
while ( ch == 1 ) :
    if length != 0 :
        ch = 0
    else :
        strn = raw_input("Fine! are you done??\nEnter the string now :")
	length=len(strn)
#length=len(strn), the above statement, is so important, as you are using 'lenght' in if

# Reverse now
i=length-1
rev = ""
while  i >= 0 :
    rev=rev+strn[i]
    i=i-1    
    
print "The reverse of '%s' is : '%s'" % ( strn, rev )

varn=raw_input()
    
# End of program
