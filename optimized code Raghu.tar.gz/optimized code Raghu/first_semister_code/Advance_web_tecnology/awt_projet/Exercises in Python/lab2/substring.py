# Given a string and positive integer n, to get the 3 substrings of the string
print "This program prints the 3 substrings, given the string and a positive integer n"

#Take the string in 'str' and positive integer in 'n' [notice converting n to int!]
strn=raw_input("Enter the string : ")
n=int(raw_input("Enter the value of n : "))    

length=len(strn)

if length == 0 :
    print "String is Empty!!"
elif n <= 0 :
    print "'n' should be positive"
elif n > length :
    print "n=%s is greater than string length %s" % (n,length)
else :
    print "The substring from start of string is :",
    print strn[0:n]
    print "The substring at the end of string is :",
    print strn[length-n:length]
    
    print "The substring at the middle of string is :",
    var3=(length-n)/2
    print strn[var3:var3+n]

varn=raw_input()

#End of program   
