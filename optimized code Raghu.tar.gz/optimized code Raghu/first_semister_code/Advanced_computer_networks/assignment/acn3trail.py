import socket
import struct
import sys


print""
print""
print"--------------------""connectionoriented  "" ------------------------                          "
fp = open("1.txt", "r")
fp.seek(52,0)
source = fp.read(8)
dest = fp.read(8)
i = int(source, 16)
j = int(dest, 16)
source = str(socket.inet_ntoa(struct.pack(">L", i)))
dest = str(socket.inet_ntoa(struct.pack(">L", j)))
fp1 = open("1.txt", "r")
fp1.seek(24,0)
e_type = fp1.read(4)
i1 = int(e_type, 16)
print "ethernet type is"
print e_type
fp1 = open("1.txt", "r")
fp1.seek(46,0)
ip_type = fp1.read(2)
i1 = int(ip_type, 16)
print "ip_type is"
print ip_type


fp1 = open("1.txt", "r")
fp1.seek(64,0)
ttl = fp1.read(2)
i1 = int(ip_type, 16)
print "ttl is"
print ttl
if ttl=="00":
  print"error:packet is not forwarded"
if ttl=="01":
  print"error:packet is forwarded upto 1 router"
if ttl=="02":
  print"error:packet is forwarded upto 2 router"
if ttl=="03":
  print"packet is forwarded upto 3 router"
else:
  print"the route is displayed below"




fp1 = open("1.txt", "r")
fp1.seek(72,0)
t_port= fp1.read(4)
i1 = int(t_port, 16)
print "tcpport is"
print t_port
print""
print""
print "source address is"
print source
print""
print""
print "destination address is"
print dest
#checking flow:
fp1 = open("1.txt", "r")
fp1.seek(29,0)
hlen= fp1.read(1)
if hlen=="0" or hlen=="1" or hlen=="2" or hlen=="3" or hlen=="4":
  print"packet is discarded"
else:
  if ((e_type=="0800") and (ip_type=="06") and (t_port=="0050")):#iam using hexadecimal notations
    print""
    print"----------------------------------------------------------------"
    print"packet belongs to webtraffic"
    fp1 = open("1.txt", "r")
    fp1.seek(48,0)
    c_s = fp1.read(4)
    e_c_s="EB32"
    if c_s==e_c_s:
      print "checksum is verified and cheksum for this packet "
      print c_s
    else:
      print"packet is discarded"


    print"----------------------------------------------------------------"
  elif ((e_type=="0800") and (ip_type=="01") and (t_port=="0050")):
    print""
    print""
    print " traffic consisting of ICMP echo request packets"
    fp1 = open("1.txt", "r")
    fp1.seek(48,0)
    c_s = fp1.read(4)
    e_c_s ="EB32"
    if c_s==e_c_s:
      print "checksum is verified and cheksum for this packet "
      print c_s
    else:
      print"packet is discarded"

  else:
    print""
    print""
    print"all other traffic (default)"
    fp1 = open("1.txt", "r")
    fp1.seek(48,0)
    c_s = fp1.read(4)
    fp1.seek(48,0)
    e_c_s ="EB32"
    if c_s==e_c_s:
      print "checksum is verified and cheksum for this packet "
      print c_s
    else:
      print"packet is discarded"





#displaying path between source and destination:
def printPath(par,dst):
    global ips
    global dst_port
    if dst!=-1:
        printPath(par,par[dst])
        flow=checkFlow(8,6,dst_port)
        print ips[dst],flow
    return
