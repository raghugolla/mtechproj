from heapq import heappush, heappop

def makeRoute(src):
    global no_of_nodes
    global topology
    n=no_of_nodes
    parent=[-1 for i in xrange(n)]
    offset=[1000 for i in xrange(n)]
    marked=[0 for i in xrange(n)]
    offset[src]=0
    list_heap=[]
    heappush(list_heap,[offset[src],src])

    while 0 in marked and list_heap:
        temp=heappop(list_heap)
        if marked[temp[1]]==0:
            marked[temp[1]]=1
            for i in range(len(topology[temp[1]])):
                if topology[temp[1]][i]!=0:
                    alt = offset[temp[1]] + topology[temp[1]][i]
                    if alt<offset[i]:
                        offset[i]=alt
                        parent[i]=temp[1]
                        heappush(list_heap,(offset[i],i))
                    
    return parent

                
def checkFlow(ethertype,ip_type,tcp_dst_port):
    if ip_type==6 and tcp_dst_port<80 and ethertype==8:
        return "flow 2"
    elif ip_type==6 and tcp_dst_port==80 and ethertype==8:
        return "flow 1"
    elif ip_type==6 and tcp_dst_port>80 and ethertype==8:
        return "flow 3"
    

def printPath(par,dst):
    global ips
    global dst_port
    if dst!=-1:
        printPath(par,par[dst])
        flow=checkFlow(8,6,dst_port)
        print ips[dst],flow
    return
    

print "Reading Topology..."
fo=open("ips.txt","r")
no_of_nodes=0
routingtable=0
ips=[]
topology=[]
for i in fo:
    no_of_nodes+=1
    temp=i.strip('\n')
    ips.append(temp)

print "Nodes : "
for i in ips:
    print i

fo=open("connections.txt","r")
print "Topology : "
for i in fo:
    topology.append(map(int,i.split()))
    
for i in topology:
    print i
    
while(1):
    print "\nsource port(16)      : "
    src_port=input()
    print "destination port(16) : "
    dst_port=input()
    print "DATA                 : "
    data_tcp=raw_input()

    print "\nTCP SEGMENT\n"
    print format(src_port,'04X')+format(dst_port,'04X')     #souce port dest port
    print format(0,'08X')                                   #seq number  
    print format(0,'08X')                                   #ack number
    print format(0,'04X')+format(0,'04X')                   #flags window size
    print format(0,'04X')+format(0,'04X')                   #checksum  urgent pointer
    print format(0,'08X')                                   #options
    print ''.join(str(format(ord(x),'02X')) for x in data_tcp)

    print "\n"
    print "source address (32)      : "
    src_ip=raw_input()
    print "destination address(32)  : "
    dst_ip=raw_input()


    print "\nIP PACKET\n"
    print format(4,'01X')+format(0,'07X')
    print format(0,'08X')
    print format(6,'02X')+format(0,'06X')
    print "".join(format(i,'02X') for i in map(int,src_ip.split('.')))
    print "".join(format(i,'02X') for i in map(int,dst_ip.split('.')))

    print format(src_port,'04X')+format(dst_port,'04X')     #souce port dest port
    print format(0,'08X')                                   #seq number  
    print format(0,'08X')                                   #ack number
    print format(0,'04X')+format(0,'04X')                   #flags window size
    print format(0,'04X')+format(0,'04X')                   #checksum  urgent pointer
    print format(0,'08X')                                   #options
    print ''.join(str(format(ord(x),'02X')) for x in data_tcp)


    if src_ip not in ips:
        print "\nSource not found!!"
        
    if dst_ip not in ips:
        print "\nDestination not found!!"
        
    else:
        print "\nSending Ethernet Frame......\n"
        par=makeRoute(ips.index(src_ip))
        print "\nPath Trace : "
        printPath(par,ips.index(dst_ip))
