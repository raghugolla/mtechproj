from Tkinter import *
import ttk
import time
import thread
from threading import Thread
import random

in_location=[]
out_location=[]
input_queue=[]
width=150
inp_height=0
a=5
b=5
no_exit=0
IQsem=0
out_req=[]
g_r=[]
buffer_size=10
colors=["yellow","brown","green","black","red"]
m_d=[]
m_do=[]
pointersi=[]
pointerso=[]


def heart(no_of_ports):
    if no_of_ports=="1":
     print "error"
    global width
    global no_exit
    global input_queue
    global IQsem
    try:
        while 1 :
            if no_exit==1:
                return 
            tags=[]
            while 1:
                if IQsem==0:
                    break
            IQsem=1
            for i in range(no_of_ports):
                yn=random.randint(0,1)
                if yn==1:
                    outport=random.randint(0,no_of_ports-1)
                    if input_queue[i][outport]<10:
                        input_queue[i][outport]+=1
                    tag="iq"
                    tags.append(tag)
                    create_circle(in_location[i][0]-width-50,in_location[i][1],b,colors[outport],tag)
            d.update()
            time.sleep(0.5)
            d.delete("iq")
            IQsem=0
            d_iq(no_of_ports)
            time.sleep(3)
            
    except BaseException ,e:
        print "heart > ",e


def c_L(x,y,a,b,color,tag):
    global no_exit
    if no_exit==1:
        return
    dx=abs(a-x)
    dy=abs(b-y)
    startx=x
    starty=y
    stepx=1
    if x>a:
        stepx=-1
        dx=-dx
    if y>b:
        dy=-dy
    for i in range(x,a,stepx):
        sy=y+dy*(i-x)/dx
        d.create_line(startx,starty,i,sy,fill=color,tags=tag)
        startx=i
        starty=sy
        d.update()
        time.sleep(0.001)
    d.create_line(startx,starty,a,b,arrow=LAST,arrowshape=(8,10,3),tags=tag)
    d.update()
def c_circle(x,y,a,b,color,tag):
    global no_exit
    if no_exit==1:
        return
    dx=abs(a-x)
    dy=abs(b-y)
    stepx=1
    r=5
    if x>a:
        stepx=-1
        dx=-dx
    if y>b:
        dy=-dy
    for i in range(x,a,stepx):
        sy=y+dy*(i-x)/dx
        create_circle(i, sy, r, color,tag)
        d.update()
        time.sleep(0.001)
        d.delete(tag)

        
def createR(x,y,w,h,color="black",fill_col="RED"):
    d.create_rectangle(x+10,y+10,x+w+10,y+h,fill=fill_col,outline=color)

def create_circle(x, y, r, fillcol="none",tagn="none"):
    return d.create_oval(x-r, y-r, x+r, y+r,fill=fillcol,tag=tagn)

def queueP(i,j,n):
    global inp_height
    x=in_location[i][0]-b-3
    y=in_location[i][1]-inp_height/2+b
    for k in range(n):
        create_circle(x-k*2*b, y+j*2*b, b, colors[j],"inner")
    
def d_iq(no_of_ports):
    for i in range(no_of_ports):
        for j in range(no_of_ports):
            if input_queue[i][j]>0:
                queueP(i,j,input_queue[i][j])
    d.update()
    
        
def ACCECPT(no_of_ports,alg):
    global g_r
    global m_d
    global m_do
    global no_exit
    d.delete("text")
    d.create_text(150,50,text="ACCECPT",tag="text")
    threads=[]
    for i in range(no_of_ports):
        if no_exit==1:
            return
        if len(g_r[i])>0:
            if alg=="PIM":
                snip=random.randint(0,len(g_r[i])-1)
                j=g_r[i][snip]
            elif alg=="RR":
                while 1:
                    if pointersi[i] in g_r[i]:
                        j=pointersi[i]
                        pointersi[i]=(pointersi[i]+1)%no_of_ports
                        break
                    pointersi[i]=(pointersi[i]+1)%no_of_ports
                
            m_d[i]=j
            m_do[j]=i
            t=Thread(target=c_L,args=(in_location[i][0],in_location[i][1],out_location[j][0],out_location[j][1],"black","ACCECPT"))
            threads.append(t)
            
    c_POIN(no_of_ports)  
    for i in threads:
        i.start()
    for i in threads:
        i.join()
        
    d.update()
    time.sleep(1)
    d.delete("ACCECPT")
    time.sleep(1)

def GRANT_REQ(no_of_ports,alg):
    global out_req
    global g_r
    global m_d
    global m_do
    global no_exit
    
    d.delete("text")
    d.create_text(150,50,text="GRANT",tag="text")
    g_r=[[] for i in range(no_of_ports)]
    threads=[]
    for i in range(no_of_ports):
        if no_exit==1:
            return
        if len(out_req[i])>0:
            if alg=="PIM":
                snip=random.randint(0,len(out_req[i])-1)
                j=out_req[i][snip]
                
            elif alg=="RR":
                while 1:
                    if pointerso[i] in out_req[i]:
                        j=pointerso[i]
                        pointerso[i]=(pointerso[i]+1)%no_of_ports
                        break
                    pointerso[i]=(pointerso[i]+1)%no_of_ports
                
            g_r[j].append(i)
            t=Thread(target=c_L,args=(out_location[i][0],out_location[i][1],in_location[j][0],in_location[j][1],"black","GRANT_REQline"))
            threads.append(t)
    CUOPNTR(no_of_ports) 
    for i in threads:
        i.start()
    for i in threads:
        i.join()        
    d.update()
    time.sleep(2)
    d.delete("GRANT_REQline")
    time.sleep(2)
    ACCECPT(no_of_ports,alg)

def transmitpack(src,dest,no_of_ports):
    global IQsem
    global no_exit
    if no_exit==1:
        return
    while 1:
            if IQsem==0:
                break
    IQsem=1
    spd=int(spud.get())
    packets=input_queue[src][dest]
    for i in range(spd):
        if input_queue[src][dest]==0:
            break
        input_queue[src][dest]-=1
        thread.start_new_thread(c_circle,(in_location[src][0],in_location[src][1],out_location[dest][0],out_location[dest][1],colors[dest],"packetstrax"))
        time.sleep(0.05)
    IQsem=0
    d.delete("inner")
    d_iq(no_of_ports)
                                
def DRAW_DIMEN():
    global m_d
    for i in range(len(m_d)):
        if m_d[i]>=0:
            j=m_d[i]
            d.create_line(in_location[i][0],in_location[i][1],out_location[j][0],out_location[j][1],fill="pink",tags="m_d")
    d.update()

    
def req(no_of_ports,alg):
    global input_queue
    global IQsem
    global out_req
    global m_d
    global m_do
    global no_exit
    while 1:
        if no_exit==1:
             break
        m_d=[ -1 for i in range(no_of_ports)]
        m_do=[ -1 for i in range(no_of_ports)]
        while 1:
            if IQsem==0:
                break
        IQsem=1
        d.delete("m_d")
        for k in range(no_of_ports):
            threads=[]
            GRANT_REQ_fl=0
            out_req=[[] for i in range(no_of_ports)]
            d.delete("text")
            d.create_text(150,50,text="REQUEST",tag="text")
            for i in range(no_of_ports):
                if m_d[i]<0:
                    for j in range(no_of_ports):
                        if m_do[j]<0:
                            if input_queue[i][j]>0:
                                GRANT_REQ_fl=1
                                out_req[j].append(i)
                                t=Thread(target=c_L,args=(in_location[i][0],in_location[i][1],out_location[j][0],out_location[j][1],"black","reqline"))
                                threads.append(t)
            for i in threads:
                i.start()
            for i in threads:
                i.join()
            IQsem=0
            d.update()
            time.sleep(2)
            d.delete("reqline")
            time.sleep(1)
            if GRANT_REQ_fl==1:
                threads2=[]
                GRANT_REQ(no_of_ports,alg)
                DRAW_DIMEN()
                for i in range(no_of_ports):
                    if m_d[i]>=0:
                        t=Thread(target=transmitpack,args=(i,m_d[i],no_of_ports))
                        threads2.append(t)
                for i in threads2:
                    i.start()
                for i in threads2:
                    i.join()
                        
qsim=0

def c_POIN(no_of_ports):
    global pointersi
    d.delete("pointeri")
    for i in range(len(pointersi)):
        xi=in_location[i][0]-width
        y=in_location[i][1]+inp_height/2+10
        r=7
        for j in range(no_of_ports):
            x=xi+j*12*8+2
            if j==pointersi[i]:
                d.create_oval(x-r, y-r, x+r, y+r,fill="black",tag="pointeri")
                continue
            d.create_oval(x-r, y-r, x+r, y+r,tag="pointeri")
            
def CUOPNTR(no_of_ports):
    global pointerso
    d.delete("pointero")
    for i in range(len(pointerso)):
        xi=out_location[i][0]
        y=out_location[i][1]+inp_height/2+10
        r=7
        for j in range(no_of_ports):
            x=xi+j*12*8+2
            if j==pointerso[i]:
                d.create_oval(x-r, y-r, x+r, y+r,fill="black",tag="pointero")
                continue
            d.create_oval(x-r, y-r, x+r, y+r,tag="pointer0")
                
    
    
def GO():
    try :
        global no_exit
        global d
        global input_queue
        global qsim
        global inp_height
        global option
        global pointersi
        global pointerso
        
        if sim["text"]=="Simulate":
            qsim=0
            no_exit=0
            d.delete("all")
            no_of_ports=int(ipp.get())
            inp_height=2*a*no_of_ports
            startx=300
            starty=300
            input_queue=[[0 for i in range(no_of_ports)] for i in range(no_of_ports)]
            sim["text"]="STOP"
            for i in range(no_of_ports):          #ip created
                createR(startx,starty+i*(50+inp_height),width,inp_height,"blue")
                in_location.append([startx+width,starty+i*(50+inp_height)+inp_height/2])
                create_circle(startx+width,starty+i*(50+inp_height)+inp_height/2,10,"green")
            for i in range(no_of_ports):           #op created
                createR(startx+400,starty+i*(50+inp_height),width,inp_height,fill_col=colors[i])
                out_location.append([startx+400,starty+i*(50+inp_height)+inp_height/2])
                create_circle(startx+400,starty+i*(50+inp_height)+inp_height/2,10,"black")
            if qsim==0:
                qsim=1
                thread.start_new_thread(heart,(no_of_ports,))
            if option.cget("text")=="RR":
                pointersi=[ 0 for i in range(no_of_ports) ]
                pointerso=[ 0 for i in range(no_of_ports) ]
                c_POIN(no_of_ports)
                CUOPNTR(no_of_ports)
                d.update()
            thread.start_new_thread(req,(no_of_ports,option.cget("text")))
        else:
            no_exit=1
            sim["text"]="Simulate"
    except BaseException ,e :
        print "GO ",e
    
    
root = Tk()
root.title("ASSIGNMENT-2:1-------------------------------------------------------------->ROUND ROBIN ALGORITHM<---------------------------------------------------------------------")

left_frame = ttk.Frame(root,padding=10)
left_frame.pack(side=BOTTOM)
right_frame = ttk.Frame(root,padding=10)
right_frame.pack(side=RIGHT)

ttk.Label(left_frame,text="INPUT_PORTS",width=20).grid(padx=5,pady=5,row=0,column=0,sticky=(W))
ipp = ttk.Entry(left_frame,width=15)
ipp.grid(row=0,column=1,sticky=(W+E))
ipp.insert(0,"ENTER_THE_NO.OF PORTS")
ipp.focus_set()


d = Canvas(right_frame,width=1500,height=1500,background="white")
d.pack()

ttk.Label(left_frame,text="",width=0).grid(padx=0,pady=0,row=300,column=0,sticky=(W))
spud = ttk.Entry(left_frame,width=0)
spud.grid(row=3000,column=1000,sticky=(W+E))
spud.insert(0,"1")

OPTIONS=["RR"]
var = StringVar()
option = ttk.OptionMenu(left_frame, var,OPTIONS[0], *OPTIONS )
option.grid(column=0, row=4,padx=10,pady=10,sticky=(EW))

sim=ttk.Button(left_frame,text="enter",command=GO)
sim.grid(row=4,column=1,padx=10,pady=10,sticky=(E+W))

root.mainloop()
