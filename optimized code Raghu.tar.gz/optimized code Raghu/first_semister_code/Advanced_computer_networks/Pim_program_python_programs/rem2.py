from Tkinter import *
import ttk
import time
import thread
from threading import Thread
import random


pointersi=[]
pointerso=[]
colors=["violet","cyan","red","blue","green"]
inp=[]
b=[]
ipQ=[]
w=150
h=0
pkh=5
pkw=5
n_e=0
IQsem=0
out_req=[]
grant_req=[]
max_buff=5
m_d=[]
m_do=[]



def c_Circle(p,q,a,b,color,tag):
    global n_e
    if n_e==1:
        return
    dx=abs(a-p)
    dy=abs(b-q)
    stepx=1
    r=5
    if p>a:
        stepx=-1
        dx=-dx
    if q>b:
        dy=-dy
    for i in range(p,a,stepx):
        sy=q+dy*(i-p)/dx
        create_circle(i, sy, r, color,tag)
        d.update()
        time.sleep(0.001)
        d.delete(tag)

def createL(p,q,a,b,color,tag):
    global n_e
    if n_e==1:
        return
    dx=abs(a-p)
    dy=abs(b-q)
    startx=p
    starty=q
    stepx=1
    if p>a:
        stepx=-1
        dx=-dx
    if q>b:
        dy=-dy
    for i in range(p,a,stepx):
        sy=q+dy*(i-p)/dx
        d.create_line(startx,starty,i,sy,fill=color,tags=tag)
        startx=i
        starty=sy
        d.update()
        time.sleep(0.001)
    d.create_line(startx,starty,a,b,arrow=LAST,arrowshape=(8,10,3),tags=tag)
    d.update()
        
def createR(p,q,w,h,color="black",fill_col="RED"):
    d.create_rectangle(p+6,q+6,p+w+6,q+h,fill=fill_col,outline=color)

def create_circle(p, q, r, fillcol="none",tagn="none"):
    return d.create_oval(p-r, q-r, p+r, q+r,fill=fillcol,tag=tagn)

def queueP(i,j,n):
    global h
    p=inp[i][0]-pkw-3
    q=inp[i][1]-h/2+pkw
    for k in range(n):
        create_circle(p-k*2*pkw, q+j*2*pkw, pkw, colors[j],"inner")
    
def drawIQ(ipno):
    for i in range(ipno):
        for j in range(ipno):
            if ipQ[i][j]>0:
                queueP(i,j,ipQ[i][j])
    d.update()
    
def imp(ipno):
    if ipno=="1":
     print "error"
    global w
    global n_e
    global ipQ
    global IQsem
    try:
        while 1 :
            if n_e==1:
                return 
            tags=[]
            while 1:
                if IQsem==0:
                    break
            IQsem=1
            for i in range(ipno):
                yn=random.randint(0,1)
                if yn==1:
                    voqno=1
                    if ipQ[i][voqno]<10:
                        ipQ[i][voqno]+=1
                    tag="iq"
                    tags.append(tag)
                    create_circle(inp[i][0]-w-50,inp[i][1],pkw,colors[voqno],tag)
            d.update()
            time.sleep(0.5)
            d.delete("iq")
            IQsem=0
            drawIQ(ipno)
            time.sleep(10)
            
    except BaseException ,e:
        print "imp > ",e
        
def ACCEPT(ipno,alg):
    global grant_req
    global m_d
    global m_do
    global n_e
    d.delete("text")
    d.create_text(150,50,text="ACCEPT",tag="text")
    threads=[]
    for i in range(ipno):
        if n_e==1:
            return
        if len(grant_req[i])>0:
            if alg=="PIM":
                snip=random.randint(0,len(grant_req[i])-1)
                j=grant_req[i][snip]
            elif alg=="RR":
                while 1:
                    if pointersi[i] in grant_req[i]:
                        j=pointersi[i]
                        pointersi[i]=(pointersi[i]+1)%ipno
                        break
                    pointersi[i]=(pointersi[i]+1)%ipno
                
            m_d[i]=j
            m_do[j]=i
            t=Thread(target=createL,args=(inp[i][0],inp[i][1],b[j][0],b[j][1],"black","ACCEPT"))
            threads.append(t)
            
    cuipointers(ipno)  
    for i in threads:
        i.start()
    for i in threads:
        i.join()
        
    d.update()
    time.sleep(1)
    d.delete("ACCEPT")
    time.sleep(1)

def grant(ipno,alg):
    global out_req
    global grant_req
    global m_d
    global m_do
    global n_e
    
    d.delete("text")
    d.create_text(150,50,text="GRANT",tag="text")
    grant_req=[[] for i in range(ipno)]
    threads=[]
    for i in range(ipno):
        if n_e==1:
            return
        if len(out_req[i])>0:
            if alg=="PIM":
                snip=random.randint(0,len(out_req[i])-1)
                j=out_req[i][snip]
                
            elif alg=="RR":
                while 1:
                    if pointerso[i] in out_req[i]:
                        j=pointerso[i]
                        pointerso[i]=(pointerso[i]+1)%ipno
                        break
                    pointerso[i]=(pointerso[i]+1)%ipno
                
            grant_req[j].append(i)
            t=Thread(target=createL,args=(b[i][0],b[i][1],inp[j][0],inp[j][1],"black","grantline"))
            threads.append(t)
    cuopointers(ipno) 
    for i in threads:
        i.start()
    for i in threads:
        i.join()        
    d.update()
    time.sleep(2)
    d.delete("grantline")
    time.sleep(2)
    ACCEPT(ipno,alg)

def tra_Pack(src,dest,ipno):
    global IQsem
    global n_e
    if n_e==1:
        return
    while 1:
            if IQsem==0:
                break
    IQsem=1
    spd=int(spud.get())
    packets=ipQ[src][dest]
    for i in range(spd):
        if ipQ[src][dest]==0:
            break
        ipQ[src][dest]-=1
        thread.start_new_thread(c_Circle,(inp[src][0],inp[src][1],b[dest][0],b[dest][1],colors[dest],"packetstrax"))
        time.sleep(0.05)
    IQsem=0
    d.delete("inner")
    drawIQ(ipno)
                                
def drawm_d():
    global m_d
    for i in range(len(m_d)):
        if m_d[i]>=0:
            j=m_d[i]
            d.create_line(inp[i][0],inp[i][1],b[j][0],b[j][1],fill="green",tags="m_d")
    d.update()

    
def req(ipno,alg):
    global ipQ
    global IQsem
    global out_req
    global m_d
    global m_do
    global n_e
    while 1:
        if n_e==1:
             break
        m_d=[ -1 for i in range(ipno)]
        m_do=[ -1 for i in range(ipno)]
        while 1:
            if IQsem==0:
                break
        IQsem=1
        d.delete("m_d")
        for k in range(ipno):
            threads=[]
            grant_fl=0
            out_req=[[] for i in range(ipno)]
            d.delete("text")
            d.create_text(150,50,text="REQUEST",tag="text")
            for i in range(ipno):
                if m_d[i]<0:
                    for j in range(ipno):
                        if m_do[j]<0:
                            if ipQ[i][j]>0:
                                grant_fl=1
                                out_req[j].append(i)
                                t=Thread(target=createL,args=(inp[i][0],inp[i][1],b[j][0],b[j][1],"black","reqline"))
                                threads.append(t)
            for i in threads:
                i.start()
            for i in threads:
                i.join()
            IQsem=0
            d.update()
            time.sleep(2)
            d.delete("reqline")
            time.sleep(1)
            if grant_fl==1:
                threads2=[]
                grant(ipno,alg)
                drawm_d()
                for i in range(ipno):
                    if m_d[i]>=0:
                        t=Thread(target=tra_Pack,args=(i,m_d[i],ipno))
                        threads2.append(t)
                for i in threads2:
                    i.start()
                for i in threads2:
                    i.join()
                        
qsim=0

def cuipointers(ipno):
    global pointersi
    d.delete("pointeri")
    for i in range(len(pointersi)):
        xi=inp[i][0]-w
        q=inp[i][1]+h/2+10
        r=7
        for j in range(ipno):
            p=xi+j*12*8+2
            if j==pointersi[i]:
                d.create_oval(p-r, q-r, p+r, q+r,fill="black",tag="pointeri")
                continue
            d.create_oval(p-r, q-r, p+r, q+r,tag="pointeri")
            
def cuopointers(ipno):
    global pointerso
    d.delete("pointero")
    for i in range(len(pointerso)):
        xi=b[i][0]
        q=b[i][1]+h/2+10
        r=7
        for j in range(ipno):
            p=xi+j*12*8+2
            if j==pointerso[i]:
                d.create_oval(p-r, q-r, p+r, q+r,fill="black",tag="pointero")
                continue
            d.create_oval(p-r, q-r, p+r, q+r,tag="pointer0")
                
    
    
def S_late():
    try :
        global n_e
        global d
        global ipQ
        global qsim
        global h
        global option
        global pointersi
        global pointerso
        
        if sim["text"]=="S_late":
            qsim=0
            n_e=0
            d.delete("all")
            ipno=int(ipp.get())
            h=2*pkh*ipno
            startx=300
            starty=300
            ipQ=[[0 for i in range(ipno)] for i in range(ipno)]
            sim["text"]="STOP"
            for i in range(ipno):          #ip created
                createR(startx,starty+i*(50+h),w,h,"blue")
                inp.append([startx+w,starty+i*(50+h)+h/2])
                create_circle(startx+w,starty+i*(50+h)+h/2,20,"red")
            for i in range(ipno):           #op created
                createR(startx+400,starty+i*(50+h),w,h,fill_col=colors[i])
                b.append([startx+400,starty+i*(50+h)+h/2])
                create_circle(startx+400,starty+i*(50+h)+h/2,20,"black")
            if qsim==0:
                qsim=1
                thread.start_new_thread(imp,(ipno,))
            if option.cget("text")=="RR":
                pointersi=[ 0 for i in range(ipno) ]
                pointerso=[ 0 for i in range(ipno) ]
                cuipointers(ipno)
                cuopointers(ipno)
                d.update()
            thread.start_new_thread(req,(ipno,option.cget("text")))
        else:
            n_e=1
            sim["text"]="S_late"
    except BaseException ,e :
        print "go ",e
    
    
root = Tk()
root.title("ASSIGNMENT2")

left_frame = ttk.Frame(root,padding=10)
left_frame.pack(side=BOTTOM)
right_frame = ttk.Frame(root,padding=10)
right_frame.pack(side=RIGHT)

ttk.Label(left_frame,text="INPUT PORTS",width=20).grid(padx=5,pady=5,row=0,column=0,sticky=(W))
ipp = ttk.Entry(left_frame,width=15)
ipp.grid(row=0,column=1,sticky=(W+E))
ipp.insert(0,"ENTER_THE_NO.OF PORTS")
ipp.focus_set()

"""ttk.Label(left_frame,text="OUTPUT PORTS\t>>",width=20).grid(padx=10,pady=10,row=2,column=0,sticky=(W))
opp = ttk.Entry(left_frame,width=8)
opp.grid(row=2,column=1,sticky=(W+E))
opp.insert(0,"3")"""

d = Canvas(right_frame,width=1500,height=1500,background="white")
d.pack()

ttk.Label(left_frame,text="",width=0).grid(padx=0,pady=0,row=300,column=0,sticky=(W))
spud = ttk.Entry(left_frame,width=0)
spud.grid(row=3000,column=1000,sticky=(W+E))
spud.insert(0,"1")

OPTIONS=["PIM"]
var = StringVar()
option = ttk.OptionMenu(left_frame, var,OPTIONS[0], *OPTIONS )
option.grid(column=0, row=4,padx=10,pady=10,sticky=(EW))

sim=ttk.Button(left_frame,text="enter",command=S_late)
sim.grid(row=4,column=1,padx=10,pady=10,sticky=(E+W))

root.mainloop()
