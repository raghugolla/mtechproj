from Tkinter import *
import ttk
import time
import thread
from threading import Thread
import random
def simulate():
    try :
        global no_exit
        global d
        global inpQ
        global qsim
        global inp_height
        global option
        global pointersi
        global pointerso
        
        if sim["text"]=="Simulate":
            qsim=0
            no_exit=0
            d.delete("all")
            ipno=int(ipp.get())
            inp_height=2*pkh*ipno
            startx=200
            starty=100
            inpQ=[[0 for i in range(ipno)] for i in range(ipno)]
            sim["text"]="STOP"
            for i in range(ipno):          #ip created
                createR(startx,starty+i*(50+inp_height),inp_width,inp_height,"blue")
                inp_loc.append([startx+inp_width,starty+i*(50+inp_height)+inp_height/2])
                create_circle(startx+inp_width,starty+i*(50+inp_height)+inp_height/2,5,"white")
            for i in range(ipno):           #op created
                createR(startx+400,starty+i*(50+inp_height),inp_width,inp_height,fill_col=colors[i])
                out_loc.append([startx+400,starty+i*(50+inp_height)+inp_height/2])
                create_circle(startx+400,starty+i*(50+inp_height)+inp_height/2,5,"white")
            if qsim==0:
                qsim=1
                thread.start_new_thread(fillIQ,(ipno,))
            if option.cget("text")=="RR":
                pointersi=[ 0 for i in range(ipno) ]
                pointerso=[ 0 for i in range(ipno) ]
                cuipointers(ipno)
                cuopointers(ipno)
                d.update()
            thread.start_new_thread(req,(ipno,option.cget("text")))
        else:
            no_exit=1
            sim["text"]="Simulate"
    except BaseException ,e :
        print "GO-->",e
root = Tk()
root.title("ASSIGNMENT")

left_frame = ttk.Frame(root,padding=10)
left_frame.pack(side=LEFT)
right_frame = ttk.Frame(root,padding=10)
right_frame.pack(side=RIGHT)

ttk.Label(left_frame,text="INPUT PORTS\t>>",width=20).grid(padx=10,pady=10,row=0,column=0,sticky=(W))
ipp = ttk.Entry(left_frame,width=8)
ipp.grid(row=0,column=1,sticky=(W+E))
ipp.insert(0,"3")
ipp.focus_set()

'''ttk.Label(left_frame,text="OUTPUT PORTS\t>>",width=20).grid(padx=10,pady=10,row=2,column=0,sticky=(W))
opp = ttk.Entry(left_frame,width=8)
opp.grid(row=2,column=1,sticky=(W+E))
opp.insert(0,"3")'''

d = Canvas(right_frame,width=800,height=500,background="white")
d.pack()

ttk.Label(left_frame,text="SPEEDUP\t>>",width=20).grid(padx=10,pady=10,row=3,column=0,sticky=(W))
spud = ttk.Entry(left_frame,width=8)
spud.grid(row=3,column=1,sticky=(W+E))
spud.insert(0,"1")

OPTIONS=["PIM","RR"]
var = StringVar()
option = ttk.OptionMenu(left_frame, var,OPTIONS[0], *OPTIONS )
option.grid(column=0, row=4,padx=10,pady=10,sticky=(EW))

sim=ttk.Button(left_frame,text="GO",command=simulate)
sim.grid(row=4,column=1,padx=10,pady=10,sticky=(E+W))

root.mainloop()
