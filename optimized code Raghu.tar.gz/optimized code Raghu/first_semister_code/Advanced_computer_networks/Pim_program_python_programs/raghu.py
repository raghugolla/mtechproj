from Tkinter import *
import ttk
import time
import thread
from threading import Thread
import random

inp_loc=[]
out_loc=[]
inpQ=[]
inp_width=150
inp_height=0
pkh=5
pkw=5
no_exit=0
IQsem=0
out_req=[]
grant_req=[]
max_buff=5
colors=["violet","cyan","red","blue","green"]
matched=[]
matchedo=[]
pointersi=[]
pointerso=[]

def createC(x,y,a,b,color,tag):
    global no_exit
    if no_exit==1:
        return
    dx=abs(a-x)
    dy=abs(b-y)
    stepx=1
    r=5
    if x>a:
        stepx=-1
        dx=-dx
    if y>b:
        dy=-dy
    for i in range(x,a,stepx):
        sy=y+dy*(i-x)/dx
        create_circle(i, sy, r, color,tag)
        d.update()
        time.sleep(0.001)
        d.delete(tag)

def createL(x,y,a,b,color,tag):
    global no_exit
    if no_exit==1:
        return
    dx=abs(a-x)
    dy=abs(b-y)
    startx=x
    starty=y
    stepx=1
    if x>a:
        stepx=-1
        dx=-dx
    if y>b:
        dy=-dy
    for i in range(x,a,stepx):
        sy=y+dy*(i-x)/dx
        d.create_line(startx,starty,i,sy,fill=color,tags=tag)
        startx=i
        starty=sy
        d.update()
        time.sleep(0.001)
    d.create_line(startx,starty,a,b,arrow=LAST,arrowshape=(8,10,3),tags=tag)
    d.update()
        
def createR(x,y,w,h,color="black",fill_col="RED"):
    d.create_rectangle(x+10000,y+10000,x+w+10000,y+h,fill=fill_col,outline=color)

def create_circle(x, y, r, fillcol="none",tagn="none"):
    return d.create_oval(x-r, y-r, x+r, y+r,fill=fillcol,tag=tagn)

def queueP(i,j,n):
    global inp_height
    x=inp_loc[i][0]-pkw-3
    y=inp_loc[i][1]-inp_height/2+pkw
    for k in range(n):
        create_circle(x-k*2*pkw, y+j*2*pkw, pkw, colors[j],"inner")
    
def drawIQ(ipno):
    for i in range(ipno):
        for j in range(ipno):
            if inpQ[i][j]>0:
                queueP(i,j,inpQ[i][j])
    d.update()
    
def fillIQ(ipno):
    global inp_width
    global no_exit
    global inpQ
    global IQsem
    try:
        while 1 :
            if no_exit==1:
                return 
            tags=[]
            while 1:
                if IQsem==0:
                    break
            IQsem=1
            for i in range(ipno):
                yn=random.randint(0,1)
                if yn==1:
                    voqno=random.randint(0,ipno-1)
                    if inpQ[i][voqno]<10:
                        inpQ[i][voqno]+=1
                    tag="iq"
                    tags.append(tag)
                    create_circle(inp_loc[i][0]-inp_width-50,inp_loc[i][1],pkw,colors[voqno],tag)
            d.update()
            time.sleep(0.5)
            d.delete("iq")
            IQsem=0
            drawIQ(ipno)
            time.sleep(3)
            
    except BaseException ,e:
        print "fillIQ > ",e
        
def accept(ipno,alg):
    global grant_req
    global matched
    global matchedo
    global no_exit
    d.delete("text")
    d.create_text(150,50,text="ACCEPT",tag="text")
    threads=[]
    for i in range(ipno):
        if no_exit==1:
            return
        if len(grant_req[i])>0:
            if alg=="PIM":
                snip=random.randint(0,len(grant_req[i])-1)
                j=grant_req[i][snip]
            elif alg=="RR":
                while 1:
                    if pointersi[i] in grant_req[i]:
                        j=pointersi[i]
                        pointersi[i]=(pointersi[i]+1)%ipno
                        break
                    pointersi[i]=(pointersi[i]+1)%ipno
                
            matched[i]=j
            matchedo[j]=i
            t=Thread(target=createL,args=(inp_loc[i][0],inp_loc[i][1],out_loc[j][0],out_loc[j][1],"black","accept"))
            threads.append(t)
            
    cuipointers(ipno)  
    for i in threads:
        i.start()
    for i in threads:
        i.join()
        
    d.update()
    time.sleep(1)
    d.delete("accept")
    time.sleep(1)

def grant(ipno,alg):
    global out_req
    global grant_req
    global matched
    global matchedo
    global no_exit
    
    d.delete("text")
    d.create_text(150,50,text="GRANT",tag="text")
    grant_req=[[] for i in range(ipno)]
    threads=[]
    for i in range(ipno):
        if no_exit==1:
            return
        if len(out_req[i])>0:
            if alg=="PIM":
                snip=random.randint(0,len(out_req[i])-1)
                j=out_req[i][snip]
                
            elif alg=="RR":
                while 1:
                    if pointerso[i] in out_req[i]:
                        j=pointerso[i]
                        pointerso[i]=(pointerso[i]+1)%ipno
                        break
                    pointerso[i]=(pointerso[i]+1)%ipno
                
            grant_req[j].append(i)
            t=Thread(target=createL,args=(out_loc[i][0],out_loc[i][1],inp_loc[j][0],inp_loc[j][1],"black","grantline"))
            threads.append(t)
    cuopointers(ipno) 
    for i in threads:
        i.start()
    for i in threads:
        i.join()        
    d.update()
    time.sleep(2)
    d.delete("grantline")
    time.sleep(2)
    accept(ipno,alg)

def transmitpack(src,dest,ipno):
    global IQsem
    global no_exit
    if no_exit==1:
        return
    while 1:
            if IQsem==0:
                break
    IQsem=1
    spd=int(spud.get())
    packets=inpQ[src][dest]
    for i in range(spd):
        if inpQ[src][dest]==0:
            break
        inpQ[src][dest]-=1
        thread.start_new_thread(createC,(inp_loc[src][0],inp_loc[src][1],out_loc[dest][0],out_loc[dest][1],colors[dest],"packetstrax"))
        time.sleep(0.05)
    IQsem=0
    d.delete("inner")
    drawIQ(ipno)
                                
def drawMatched():
    global matched
    for i in range(len(matched)):
        if matched[i]>=0:
            j=matched[i]
            d.create_line(inp_loc[i][0],inp_loc[i][1],out_loc[j][0],out_loc[j][1],fill="green",tags="matched")
    d.update()

    
def req(ipno,alg):
    global inpQ
    global IQsem
    global out_req
    global matched
    global matchedo
    global no_exit
    while 1:
        if no_exit==1:
             break
        matched=[ -1 for i in range(ipno)]
        matchedo=[ -1 for i in range(ipno)]
        while 1:
            if IQsem==0:
                break
        IQsem=1
        d.delete("matched")
        for k in range(ipno):
            threads=[]
            grant_fl=0
            out_req=[[] for i in range(ipno)]
            d.delete("text")
            d.create_text(150,50,text="REQUEST",tag="text")
            for i in range(ipno):
                if matched[i]<0:
                    for j in range(ipno):
                        if matchedo[j]<0:
                            if inpQ[i][j]>0:
                                grant_fl=1
                                out_req[j].append(i)
                                t=Thread(target=createL,args=(inp_loc[i][0],inp_loc[i][1],out_loc[j][0],out_loc[j][1],"black","reqline"))
                                threads.append(t)
            for i in threads:
                i.start()
            for i in threads:
                i.join()
            IQsem=0
            d.update()
            time.sleep(2)
            d.delete("reqline")
            time.sleep(1)
            if grant_fl==1:
                threads2=[]
                grant(ipno,alg)
                drawMatched()
                for i in range(ipno):
                    if matched[i]>=0:
                        t=Thread(target=transmitpack,args=(i,matched[i],ipno))
                        threads2.append(t)
                for i in threads2:
                    i.start()
                for i in threads2:
                    i.join()
                        
qsim=0

def cuipointers(ipno):
    global pointersi
    d.delete("pointeri")
    for i in range(len(pointersi)):
        xi=inp_loc[i][0]-inp_width
        y=inp_loc[i][1]+inp_height/2+10
        r=7
        for j in range(ipno):
            x=xi+j*12*8+2
            if j==pointersi[i]:
                d.create_oval(x-r, y-r, x+r, y+r,fill="black",tag="pointeri")
                continue
            d.create_oval(x-r, y-r, x+r, y+r,tag="pointeri")
            
def cuopointers(ipno):
    global pointerso
    d.delete("pointero")
    for i in range(len(pointerso)):
        xi=out_loc[i][0]
        y=out_loc[i][1]+inp_height/2+10
        r=7
        for j in range(ipno):
            x=xi+j*12*8+2
            if j==pointerso[i]:
                d.create_oval(x-r, y-r, x+r, y+r,fill="black",tag="pointero")
                continue
            d.create_oval(x-r, y-r, x+r, y+r,tag="pointer0")
                
    
    
def simulate():
    try :
        global no_exit
        global d
        global inpQ
        global qsim
        global inp_height
        global option
        global pointersi
        global pointerso
        
        if sim["text"]=="Simulate":
            qsim=0
            no_exit=0
            d.delete("all")
            ipno=int(ipp.get())
            inp_height=2*pkh*ipno
            startx=300
            starty=300
            inpQ=[[0 for i in range(ipno)] for i in range(ipno)]
            sim["text"]="STOP"
            for i in range(ipno):          #ip created
                createR(startx,starty+i*(50+inp_height),inp_width,inp_height,"blue")
                inp_loc.append([startx+inp_width,starty+i*(50+inp_height)+inp_height/2])
                create_circle(startx+inp_width,starty+i*(50+inp_height)+inp_height/2,20,"RED")
            for i in range(ipno):           #op created
                createR(startx+400,starty+i*(50+inp_height),inp_width,inp_height,fill_col=colors[i])
                out_loc.append([startx+400,starty+i*(50+inp_height)+inp_height/2])
                create_circle(startx+400,starty+i*(50+inp_height)+inp_height/2,20,"black")
            if qsim==0:
                qsim=1
                thread.start_new_thread(fillIQ,(ipno,))
            if option.cget("text")=="RR":
                pointersi=[ 0 for i in range(ipno) ]
                pointerso=[ 0 for i in range(ipno) ]
                cuipointers(ipno)
                cuopointers(ipno)
                d.update()
            thread.start_new_thread(req,(ipno,option.cget("text")))
        else:
            no_exit=1
            sim["text"]="Simulate"
    except BaseException ,e :
        print "go ",e
    
    
root = Tk()
root.title("*************************ASSIGNMENT 2:1)----------parallel ierative matching---------------******************")

left_frame = ttk.Frame(root,padding=10)
left_frame.pack(side=BOTTOM)
right_frame = ttk.Frame(root,padding=10)
right_frame.pack(side=RIGHT)

ttk.Label(left_frame,text="INPUT PORTS",width=20).grid(padx=5,pady=5,row=0,column=0,sticky=(W))
ipp = ttk.Entry(left_frame,width=15)
ipp.grid(row=0,column=1,sticky=(W+E))
ipp.insert(0,"ENTER_THE_NO.OF PORTS")
ipp.focus_set()



d = Canvas(right_frame,width=1500,height=1500,background="white")
d.pack()

ttk.Label(left_frame,text="",width=0).grid(padx=0,pady=0,row=300,column=0,sticky=(W))
spud = ttk.Entry(left_frame,width=0)
spud.grid(row=3000,column=1000,sticky=(W+E))
spud.insert(0,"1")

OPTIONS=["PIM"]
var = StringVar()
option = ttk.OptionMenu(left_frame, var,OPTIONS[0], *OPTIONS )
option.grid(column=0, row=4,padx=10,pady=10,sticky=(EW))



sim=ttk.Button(left_frame,text="enter",command=simulate)
sim.grid(row=4,column=1,padx=10,pady=10,sticky=(E+W))


root.mainloop()
